#include "BTDF.h"


BTDF::BTDF(void){}
BTDF::BTDF(const BTDF& btdf){}
BTDF& BTDF::operator= (const BTDF& rhs){
    return *this;
}
BTDF::~BTDF(void){}