CODE CITATIONS:

Nearly all of the code I wrote in the ray tracer was heavily taken from the Ray Tracing From the Ground Up book by Kevin Suffern. However, I re-typed all of this code by hand / line-by-line. I did this to understand the code better and make it more similar to my coding style / deleted things I thought were unnecessary. I also used a few other websites for topics that were not covered well in Suffern's book.

Most of the code: Ray Tracing From the Ground Up: Kevin Suffern
Most of the code (Fork of Kevin Suffern's code): https://github.com/tfiner/RTFGU/blob/f1d6c164afeb8bd38b74171582b06d9d30cc7e25/src/geo_obj/BBox.h
OBJ Parser: https://stackoverflow.com/questions/21120699/c-obj-file-parser
BVH: https://graphics.stanford.edu/~boulos/papers/efficient_notes.pdf
BVH: https://www.scratchapixel.com/lessons/advanced-rendering/introduction-acceleration-structure/bounding-volume-hierarchy-BVH-part1
